||||||||||||||||||||||||||||||||||||||||||||||||||||||
|| 					        BLACKMOTH MOD                   ||
||||||||||||||||||||||||||||||||||||||||||||||||||||||
by Gradow


======================================================

FEATURES

 - A hybrid of fast-paced and risky action mod!
 - Your main form of attack is you Dash!
 - Use charms and upgrades to upgrade your dashing capabilities!
 - Develop new strategies for bosses and enemies!
 - Find new paths and new ways to explore with a new movement upgrade!
 
 =====================================================
 
 MOD INSTALLATION INSTRUCTIONS
 
 + STEAM VERSION +
 
 1 - Open the containing folder for the game (either right-click it on
 Steam and then Properties->Local Files-> Browse Local Files or simply go to
 <installation driver>:\Program Files (x86)\Steam\steamapps\common\Hollow Knight);
 2 - Copy and paste the \hollow_knight_data\ folder contained in the zip, inside the above-mentioned folder;
 5 - To avoid any possible unwanted interactions, only try this mod on a New Game - loading existing save data
 may cause corruption or other issues;
 6 - ???
 7 - Enjoy!!!
 
 
=======================================================

 ISSUES / TROUBLESHOOTING
 
  Please notify me of any and all un-intended/wanted/expected interactions and bugs.
  I'm also open to suggestions and improvements!
  You can find me at Discord [Gradow#9473] or the Hollow Knight discord channel on the #modding channel.
  This mod should be always up-to-date with the Steam release. If it's not working with a recent release, please contact me!

=======================================================

 CREDITS
 
  This mod was made by Gradow ([Gradow#9473] on Discord). The API this mod uses as a base to work was made by Seanpr and Firzen.
  The initial port of this mod to the API, as well as the 8-directional dash, was done originally by Seanpr and then expanded upon
  by me. Credit also goes to all the amazing folks at the Hollow Knigh#modding subchannel on Discord.
  
  
  Special thanks to:
  - Wyza
  - KDT
  - Seanpr
  - 56
  - Verulean (chief guy-who-breaks-things) 
  - AvengingAngle (chief guy-who-fixes-things-with-ONE-LINE) 
  
========================================================
========================================================
========================================================
=======================SPOILERS=========================
========================================================
========================================================
======================================================== 
 
 IN-DEPTH FEATURES [SPOILERS!!!!!]
 

 - Nail damage always set to 1;
 - Dash damage set to what Nail damage would be at that point normally;
 - Hero starts with full (vanilla) dashing capabilities;
 - Cooldown between dashes reduced by default;
 - Longnail Charm increases dash distance by 20%;
 - Mark of Pride Charm increases dash distance by 30%;
 - Quickslash Charm allows the Hero to chain dashes infinitely;
 - Dashmaster Charm allows the Hero to chain 3 dashes;
 - Heavy Blow Charm makes the enemies recoil when hit with the dash;
 - Mothwing Cloak allows for 8-directional dash;
 - Shade Cloak allows the Hero to recover SOUL by dashing at a rate of 3 SOUL/dash and dash through walls;
 - Sharp Shadow Charm doubles the dash damage;
 - Beating Nightmare King Grimm allows the Hero to Super Dash in midair and also change the direction of Super Dashes.
 
 ======================================================